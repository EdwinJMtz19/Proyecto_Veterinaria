package com.mycompany.utils.pagination;

public interface EventPagination {

    public void pageChanged(int page);
}
