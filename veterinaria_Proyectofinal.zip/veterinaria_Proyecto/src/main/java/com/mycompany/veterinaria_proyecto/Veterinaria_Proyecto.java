/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.veterinaria_proyecto;

import com.mycompany.views.FromLogin;

/**
 *
 * @author 52951
 */
public class Veterinaria_Proyecto {

    public static void main(String[] args) throws Exception {

       new FromLogin().setVisible(true);
    }
    
   
    
}
